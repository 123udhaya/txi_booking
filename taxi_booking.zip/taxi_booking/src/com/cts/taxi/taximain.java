package com.cts.taxi;

import java.util.List;

public class taximain {
private List<cusinfo> cusinfos;
private List<driverinfo> driverinfos;
private List<cabdetails> cabinfos;
private List<currentpos> curpos;
private List<customer_whole_book> c_w;
private List<driver_whole_work> d_w;
private List<reqs> req;
public taximain(List<cusinfo> cusinfos, List<driverinfo> driverinfos, List<cabdetails> cabinfos,
		List<currentpos> curpos, List<customer_whole_book> c_w, List<driver_whole_work> d_w,List<reqs> req) {
	super();
	this.cusinfos = cusinfos;
	this.driverinfos = driverinfos;
	this.cabinfos = cabinfos;
	this.curpos = curpos;
	this.c_w = c_w;
	this.d_w = d_w;
	this.req=req;
}
public List<cusinfo> getCusinfos() {
	return cusinfos;
}
public void setCusinfos(List<cusinfo> cusinfos) {
	this.cusinfos = cusinfos;
}
public List<driverinfo> getDriverinfos() {
	return driverinfos;
}
public void setDriverinfos(List<driverinfo> driverinfos) {
	this.driverinfos = driverinfos;
}
public List<cabdetails> getCabinfos() {
	return cabinfos;
}
public void setCabinfos(List<cabdetails> cabinfos) {
	this.cabinfos = cabinfos;
}
public List<currentpos> getCurpos() {
	return curpos;
}
public void setCurpos(List<currentpos> curpos) {
	this.curpos = curpos;
}
public List<customer_whole_book> getC_w() {
	return c_w;
}
public void setC_w(List<customer_whole_book> c_w) {
	this.c_w = c_w;
}
public List<driver_whole_work> getD_w() {
	return d_w;
}
public void setD_w(List<driver_whole_work> d_w) {
	this.d_w = d_w;
}
public List<reqs> getReq() {
	return req;
}
public void setReq(List<reqs> req) {
	this.req = req;
}


}
