package com.cts.taxi;

public class reqs {
private String D_name;
private int cab_id;
private String C_name;
private String src;
private String dn;
private int at;
public reqs(String d_name, int cab_id, String c_name, String src, String dn,int at) {
	super();
	D_name = d_name;
	this.cab_id = cab_id;
	C_name = c_name;
	this.src = src;
	this.dn = dn;
	this.at=at;
}
public String getD_name() {
	return D_name;
}
public void setD_name(String d_name) {
	D_name = d_name;
}
public int getCab_id() {
	return cab_id;
}
public void setCab_id(int cab_id) {
	this.cab_id = cab_id;
}
public String getC_name() {
	return C_name;
}
public void setC_name(String c_name) {
	C_name = c_name;
}
public String getSrc() {
	return src;
}
public void setSrc(String src) {
	this.src = src;
}
public String getDn() {
	return dn;
}
public void setDn(String dn) {
	this.dn = dn;
}
public int getAt() {
	return at;
}
public void setAt(int at) {
	this.at = at;
}

}
