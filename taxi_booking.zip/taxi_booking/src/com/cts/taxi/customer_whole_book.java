package com.cts.taxi;

public class customer_whole_book {
	private String name;
	private String source;
	private String destin;
	private int amt_spent;
	private int cab_id;
	
	public customer_whole_book(String name, String source, String destin, int amt_spent,int cab_id) {
		super();
		this.name = name;
		this.source = source;
		this.destin = destin;
		this.amt_spent = amt_spent;
		this.cab_id=cab_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestin() {
		return destin;
	}
	public void setDestin(String destin) {
		this.destin = destin;
	}
	public int getAmt_spent() {
		return amt_spent;
	}
	public void setAmt_spent(int amt_spent) {
		this.amt_spent = amt_spent;
	}
	public int getCab_id() {
		return cab_id;
	}
	public void setCab_id(int cab_id) {
		this.cab_id = cab_id;
	}
}
