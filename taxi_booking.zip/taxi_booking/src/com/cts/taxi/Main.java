package com.cts.taxi;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
private static Scanner sc;

public static void main(String[] args)
{
	//Enter customer information
	List<cusinfo> ci=new ArrayList<>();
	cusinfo c1=new cusinfo("udhaya","female",21);
	cusinfo c2=new cusinfo("surya","female",16);
	cusinfo c3=new cusinfo("sugi","female",17);
	cusinfo c4=new cusinfo("tharun","male",18);
	ci.add(c1);
	ci.add(c2);
	ci.add(c3);
	ci.add(c4);
	
	//Enter driver information
	List<driverinfo> di=new ArrayList<>();
	driverinfo d1=new driverinfo("raj","male",25,1);
	driverinfo d2=new driverinfo("gokul","male",26,2);
	driverinfo d3=new driverinfo("prksh","male",27,3);
	driverinfo d4=new driverinfo("kolk","male",28,4);
	di.add(d1);
	di.add(d2);
	di.add(d3);
	di.add(d4);
		
	//Enter cab information
	List<cabdetails> cabi=new ArrayList<>();
	cabdetails cab1=new cabdetails(0,"a",0);
	cabdetails cab2=new cabdetails(4,"b",4);
	cabdetails cab3=new cabdetails(3,"c",7);
	cabdetails cab4=new cabdetails(3,"d",10);
	cabdetails cab5=new cabdetails(2,"e",14);
	cabdetails cab6=new cabdetails(8,"f",22);
	cabdetails cab7=new cabdetails(3,"g",25);
	cabdetails cab8=new cabdetails(4,"h",29);
	cabi.add(cab1);
	cabi.add(cab2);
	cabi.add(cab3);
	cabi.add(cab4);
	cabi.add(cab5);
	cabi.add(cab6);
	cabi.add(cab7);
	cabi.add(cab8);
	
	//Enter current cab position details
	List<currentpos> cpos=new ArrayList<>();
	currentpos cp1=new currentpos("b",1);
	currentpos cp2=new currentpos("g",3);
	currentpos cp3=new currentpos("c",0);
	currentpos cp4=new currentpos("f",4);
	currentpos cp5=new currentpos("a",0);
	currentpos cp6=new currentpos("d",2);
	currentpos cp7=new currentpos("e",0);
	currentpos cp8=new currentpos("h",0);
	cpos.add(cp1);
	cpos.add(cp2);
	cpos.add(cp3);
	cpos.add(cp4);
	cpos.add(cp5);
	cpos.add(cp6);
	cpos.add(cp7);
	cpos.add(cp8);
	
	//Creating list for total ride of customer
	List<customer_whole_book> cride=new ArrayList<>();
	
	//Creating list for total ride of cab driver
	List<reqs> rq=new ArrayList<>();
	List<driver_whole_work> dride=new ArrayList<>();
	taximain tx=new taximain(ci,di,cabi,cpos, cride, dride,rq);
	sc = new Scanner(System.in);
	
	//taxi booking process
	System.out.println("\n******ONLINE TAXI BOOKING********");
	int y=1;
	do{
		System.out.println("Choose one");
		System.out.println("1.customer view\n2.driver view\n3.view customer ride details\n4.view driver ride details");
		int i;
		i=sc.nextInt();
		switch(i)
		{
			case 1:
				customer_process(ci,di,cabi,cpos,cride,dride,rq);
				break;
				
			case 2:
				driver_process(ci,di,cabi,cpos,cride,dride,rq);
				break;
			case 3:
				cusride_details(cride);
				break;
			case 4:
				drride_details(dride);
				break;
		}
		System.out.println("Do u want to continue:if (yes) PRESS 1 ELSE PRESS 2\n");	
		y=sc.nextInt();
	}
	while(y==1);
}




//customer taxi booking process
private static void customer_process(List<cusinfo> ci, List<driverinfo> di, List<cabdetails> cabi, List<currentpos> cpos, List<customer_whole_book> cride, List<driver_whole_work> dride,List<reqs> req) {
	String nm;
	String src;
	String dn;
	String ans = null;
	int i1,itr,f=0,itr1,d1 = 0,d2 = 0,at;
	System.out.println("Enter the name    \n");
	nm=sc.next();
	System.out.println("\nAvailable cab location with ID.........");
	for(i1=0;i1<cpos.size();i1++)
	{
		if(cpos.get(i1).getCabid()!=0)
		{
			System.out.println("Cab id  "+cpos.get(i1).getCabid()+"    Location  "+cpos.get(i1).getLoc());
		}
	}
	System.out.println("Enter the source   \n");
	src=sc.next();
	System.out.println("Enter the destination  \n");
	dn=sc.next();
	System.out.println(nm+" "+src+"  "+dn);
	//To identify distance between source and destination
	for(i1=0;i1<cabi.size();i1++)
	{
		if(cabi.get(i1).getLoc_name().equals(src))
		{
			d1=cabi.get(i1).getFar();
		}
		if(cabi.get(i1).getLoc_name().equals(dn))
		{
			d2=cabi.get(i1).getFar();
		}
	}
	at=(d2-d1)*10;
	i1=cpos.size();
	for(itr=0;itr<i1;itr++)
	{
		String sr=cpos.get(itr).getLoc();
		int y1=cpos.get(itr).getCabid();
		if((sr.equals(src))&&(y1!=0))
		{
			f=1;
			break;
			
		}
		else
		{
			f=0;
			
		}
	}
	if(f==1)
	{
		System.out.println("Cab is available in your location...\n");
	}
	else
	{
		//System.out.println("cab is not available in ur location...");
		List<Integer> cab_avail=new ArrayList<>();
		List<String> avail_loc=new ArrayList<>();
		List<String> cabavail_loc=new ArrayList<>();
		int main = 0;
		//getting the far of source location entered by customer..
		for(itr=0;itr<cabi.size();itr++)
		{
			String s1=cabi.get(itr).getLoc_name();
			if(s1.equals(src))
			{
				main=cabi.get(itr).getFar();
			}
		}
		//adding the available cab present location into the arraylist
		for(itr=0;itr<cpos.size();itr++)
		{
			int y=cpos.get(itr).getCabid();
			if(y!=0)
			{
				avail_loc.add(cpos.get(itr).getLoc());
				//System.out.println(avail_loc);
			}
		}
		//adding the nearest location and far into the arraylist and if else condition to get the far from the source
		for(itr=0;itr<cabi.size();itr++)
		{
			for(itr1=0;itr1<avail_loc.size();itr1++)
			{
				String s3=avail_loc.get(itr1);
				if(s3.equals(cabi.get(itr).getLoc_name()))
				{
					int y2=cabi.get(itr).getFar();
					if(y2<main)
					{
						cab_avail.add(main-y2);
						cabavail_loc.add(cabi.get(itr).getLoc_name());
					}
					else
					{
						cab_avail.add(y2-main);
						cabavail_loc.add(cabi.get(itr).getLoc_name());
					}
				}
			}
		}
		//to get a minimum far of location from source
	int min=cab_avail.get(0);
		String s4 = " ";
		for(itr1=0;itr1<cab_avail.size();itr1++)
		{
			if(min>=cab_avail.get(itr1))
			{
				min=cab_avail.get(itr1);
				s4=cabavail_loc.get(itr1);
			}
		}
		int lc=0;
		//to print the cabid of resulted location..
		for(itr1=0;itr1<cpos.size();itr1++)
		{
			String s5=cpos.get(itr1).getLoc();
			if(s5.equals(s4))
			{
				lc=cpos.get(itr1).getCabid();
			}
		}
		System.out.println("cab id "+lc+" is available on "+s4+" location...\n");
		System.out.println("\nDriver details..\n");
		String dname = null;
		int f1=0;
		for(i1=0;i1<di.size();i1++){
			if(lc==di.get(i1).getCab_id())
			{
				System.out.println("\nName  =  "+di.get(i1).getName());
				dname=di.get(i1).getName();
				System.out.println("Gender  =  "+di.get(i1).getGender());
				System.out.println("Age  =  "+di.get(i1).getAge()+"\n");
				f1=1;
			}
			if(f1==1)
			{
				break;
			}
		}
		System.out.println("\nDo u want this ride...say YES or NO..");
		ans=sc.next();
		
		if(ans.equalsIgnoreCase("yes"))
		{
			reqs c1=new reqs(dname,lc,nm,src,dn,at);
	        req.add(c1);
			System.out.println("\nSuccessfully booked");
		}
		else
		{
			System.out.println("\nNot booked..Still want the ride search for others");
		}
	}
		
}

//driver ride acepting process
private static void driver_process(List<cusinfo> ci, List<driverinfo> di, List<cabdetails> cabi, List<currentpos> cpos, List<customer_whole_book> cride, List<driver_whole_work> dride,List<reqs> req)
{
	String name,s,d;
	//currentpos cp=new currentpos();
	int id,i1,f1=0;
	System.out.println("\nEnter your name");
	name=sc.next();
	System.out.println("\nEnter your cab id");
	id=sc.nextInt();
	for(i1=0;i1<req.size();i1++)
	{
		if((req.get(i1).getD_name().equals(name))&&(req.get(i1).getCab_id()==id))
		{
			System.out.println("\nCustomer details are-----");
			System.out.println("\n"+req.get(i1).getC_name()+"   "+req.get(i1).getSrc()+"   "+req.get(i1).getDn());
			driver_whole_work d1=new driver_whole_work(name, req.get(i1).getSrc(),req.get(i1).getDn(),req.get(i1).getAt(),id);
			dride.add(d1);
			customer_whole_book c1=new customer_whole_book(req.get(i1).getC_name(), req.get(i1).getSrc(),req.get(i1).getDn(),req.get(i1).getAt(),id);
			cride.add(c1);
			System.out.println("\nSuccessfully completed the ride....");
			s=req.get(i1).getSrc();
			d=req.get(i1).getDn();
			for(int i2=0;i2<cpos.size();i2++)
			{
				if(s.equals(cpos.get(i2).getLoc()))
				{
				    //cpos.cabid=0;
				}
				if(d.equals(cpos.get(i2).getLoc()))
				{

				}
				
			}
			
			f1=1;

		}
		else
		{
			System.out.println("\nCurrently you dont have any requests..");
		}
		if(f1==1)
		{
			break;
		}
	}
	
}
private static void drride_details(List<driver_whole_work> dride) {
	int i;
	System.out.println("\n--------Driver ride details......");
	for(i=0;i<dride.size();i++)
	{
		System.out.println("\nDriver name :"+dride.get(i).getName()+"\ncab id :"+dride.get(i).getCab_id()+"\nSource :"+dride.get(i).getSource()+"\nDestination :"+dride.get(i).getDestin()+"\nAmount received :"+dride.get(i).getAmt_recv());
	}

}


private static void cusride_details(List<customer_whole_book> cride) {
	int i;
	System.out.println("\n--------Customer ride details......");
	for(i=0;i<cride.size();i++)
	{
		System.out.println("\ncustomer name :"+cride.get(i).getName()+"\ncab id :"+cride.get(i).getCab_id()+"\nsource :"+cride.get(i).getSource()+"\nDestination :"+cride.get(i).getDestin()+"\namount spent :"+cride.get(i).getAmt_spent());
	}
	
}

}
