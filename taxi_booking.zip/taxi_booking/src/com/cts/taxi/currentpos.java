package com.cts.taxi;

public class currentpos {
private String loc;
private int cabid;
public currentpos(String loc, int cabid) {
	super();
	this.loc = loc;
	this.cabid = cabid;
}
public String getLoc() {
	return loc;
}
public void setLoc(String loc) {
	this.loc = loc;
}
public int getCabid() {
	return cabid;
}
public void setCabid(int cabid) {
	this.cabid = cabid;
}


}
