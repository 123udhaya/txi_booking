package com.cts.taxi;

public class cabdetails {

private int far_p;
private String loc_name;
private int far;
public cabdetails(int far_p, String loc_name, int far) {
	super();
	this.far_p = far_p;
	this.loc_name = loc_name;
	this.far = far;
}

public int getFar_p() {
	return far_p;
}

public void setFar_p(int far_p) {
	this.far_p = far_p;
}

public String getLoc_name() {
	return loc_name;
}
public void setLoc_name(String loc_name) {
	this.loc_name = loc_name;
}
public int getFar() {
	return far;
}
public void setFar(int far) {
	this.far = far;
}

}
