package com.cts.taxi;

public class driver_whole_work {
private String name;
private String source;
private String destin;
private int amt_recv;
private int cab_id;

public driver_whole_work(String name, String source, String destin, int amt_recv,int cab_id) {
	super();
	this.name = name;
	this.source = source;
	this.destin = destin;
	this.amt_recv = amt_recv;
	this.cab_id=cab_id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getSource() {
	return source;
}
public void setSource(String source) {
	this.source = source;
}
public String getDestin() {
	return destin;
}
public void setDestin(String destin) {
	this.destin = destin;
}
public int getAmt_recv() {
	return amt_recv;
}
public void setAmt_recv(int amt_recv) {
	this.amt_recv = amt_recv;
}
public int getCab_id() {
	return cab_id;
}
public void setCab_id(int cab_id) {
	this.cab_id = cab_id;
}
}
